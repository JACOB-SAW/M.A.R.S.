# M.A.R.S.

**Multiple Agent Resource System**: a council of agents with different parameters and biases that make decisions together, evolve their own parameters from results, and search for a purpose.

## How it works

- **Council**: several agents (cautious, curious, gambler, ...) each propose an action. An arbiter picks one by weighted vote.
- **Reputation**: agents gain influence when the actions they backed paid off.
- **Evolution**: after each cycle the worst agents are replaced by mutated clones of the best; the rest are tuned slightly.
- **Purpose search**: the system trials candidate purposes (reward weightings), scores them with a fixed anchor (learning progress, consistency, safety), and adopts one only with approval. It then generates variants and keeps testing.
- **Safety**: protected limits in `config/protected.yaml` clamp every change, purpose changes go through an approval gate, and every cycle is logged and snapshotted.

## Quick start

```bash
pip install -e ".[dev]"
pytest
python scripts/run_sim.py --cycles 60
```

Options: `--cycles N`, `--seed N`, `--approval auto|ask|deny`, `--resume`.

Logs are written to `data/logs/` (JSONL) and snapshots to `data/snapshots/`. Both are gitignored.

## Layout

```
config/       default.yaml (agents, rates), protected.yaml (immutable limits)
src/mars/
  agents/       agent interface, params, heuristic agent
  council/      arbiter, reputation, population
  evolution/    mutation, selection, bounds
  purpose/      hypotheses, evaluator, manager, anchor (fixed criteria)
  environment/  gridworld
  safety/       guardrails, approval, rollback
  telemetry/    logger
tests/
```

## Safety notes

`config/protected.yaml` and `src/mars/purpose/anchor.py` are the protected core. Only a human edits them, between runs. Nothing in the running system writes to them.

## Status

Early prototype. Purposes are currently variations on three reward weights, and agents evolve between cycles rather than learning within them.
